if (!("rstudioapi" %in% rownames(installed.packages()))) install.packages("rstudioapi")
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

set.seed(1)
options(warn = -1, digits = 4)

air = read.table("T1-5.dat", header = F, col.names = c('x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7'))
air = air[, c('x1', 'x2', 'x5', 'x6')]

res.fa.pca = psych::principal(r = cov(air), covar = T, nfactors = 2, rotate = 'none') 
res.fa.pca$loadings

res.fa.ml = psych::fa(r = cov(air), covar = T, fm = 'ml', nfactors = 2, rotate = 'none', max.iter = 100)
res.fa.ml$loadings