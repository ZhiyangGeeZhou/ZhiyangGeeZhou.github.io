xbar = c(155.6, 14.7) 
S = cbind(c(7476.45, 303.62), c(303.62, 26.19))
eigenS = eigen(S)

eigenVal = eigenS$values
eigenVec = eigenS$vectors

plot(ellipse::ellipse(S, centre = xbar), type = "l", xlab = "Sales", ylab= "Profits")
abline(a = xbar[2] - eigenVec[2, 1]*xbar[1]/eigenVec[1, 1], b = eigenVec[2,1]/eigenVec[1,1], col = "blue", lty = 3)
abline(a = xbar[2] - eigenVec[2, 2]*xbar[1]/eigenVec[1, 2], b = eigenVec[2,2]/eigenVec[1,2], col = "red", lty = 3)

### in plot(), use asp = 1 rather than letting R set it automatically
plot(ellipse::ellipse(S, centre = xbar), type = "l", xlab = "Sales", ylab= "Profits", asp = 1)
abline(a = xbar[2] - eigenVec[2, 1]*xbar[1]/eigenVec[1, 1], b = eigenVec[2,1]/eigenVec[1,1], col = "blue", lty = 3)
abline(a = xbar[2] - eigenVec[2, 2]*xbar[1]/eigenVec[1, 2], b = eigenVec[2,2]/eigenVec[1,2], col = "red", lty = 3)