## Don't forget to put the data file into your current working directory.
set <- read.table("P1-4.dat")
x1 <- set[[1]]
x2 <- set[[2]]

## Define a layout. Here we devide the plotting area to four subareas. 
## For details, read the help file for function "layout".
nf <- layout(matrix(c(3,1,0,2), 2, 2, byrow = TRUE), c(1,5), c(5,1), TRUE)
## Show the layout which give an idea about how the plots will distribute before plotting them.
layout.show(nf)

## Plot scatter plot first.
## par(mar = c()) is used to leave proper margins around plots. Do not change it!
par(mar=c(5, 4, 2, 2))
plot(x1, x2, xlab = "x1 label", ylab = "x2 label")

## Then plot dot diagram under the scatter plot, and dot diagram to the left of it.
## Some setting of axis is just to make the plots look better.
par(mar = c(3, 4, 2, 2))
plot(x1, rep(1, length(x1)), xlab = "", ylab = "", axes = F)
axis(side = 3)
par(mar = c(5, 3, 2, 2))
plot(rep(1, length(x2)), x2, xlab = "", ylab = "", axes = F)
axis(side = 4)